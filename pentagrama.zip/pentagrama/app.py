from flask import Flask, render_template, request, redirect, url_for, flash
from flask_mysqldb import MySQL 


app = Flask(__name__) 
app.secret_key = 'mi_clave_secreta_super_segura' 

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'pentagrama' 
mysql = MySQL(app) 




@app.route('/home')
@app.route('/')
def home():
    """Ruta para la página de inicio."""
    return render_template('index.html')

@app.route('/servicios')
def servicios():
    """Ruta para la página de servicios."""
    return render_template('servicios.html')

@app.route('/contacto')
def contacto():
    """Ruta para la página de contacto."""
    return render_template('contacto.html')

@app.route('/login')
def login():
    """Ruta para la página de inicio de sesión."""
    return render_template('login.html') 

@app.route('/add_item_form')
def add_item_form():
    """Ruta para mostrar el formulario de agregar un nuevo ítem."""

    return render_template('agregar.html') 
    


@app.route('/admin/listar')
def listar_items():
    """Muestra la lista de ítems de la base de datos."""
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM items')
    data = cur.fetchall() 
    cur.close()
    return render_template('Lista.html', items=data)
    
@app.route('/add_item', methods=['POST'])
def add_item():
    if request.method == 'POST':
        nombre = request.form['nombre']
        interes = 1 if 'interes' in request.form else 0 
        precio = request.form['precio']
        producto = request.form['producto']
        comentario = request.form['comentario']

        cur = mysql.connection.cursor()
        cur.execute(
            'INSERT INTO items (nombre, interes, precio, producto, comentario) VALUES (%s, %s, %s, %s, %s)',
            (nombre, interes, precio, producto, comentario)
        )
        mysql.connection.commit()
        cur.close()
        flash('Ítem agregado correctamente', 'success')
        return redirect(url_for('listar_items')) 
    
@app.route('/update/<int:id>', methods=['POST'])
def update_item(id):
    if request.method == 'POST':
        nombre = request.form['nombre']
        interes = 1 if 'interes' in request.form else 0
        precio = request.form['precio']
        producto = request.form['producto']
        comentario = request.form['comentario'] 
        
        cur = mysql.connection.cursor()
        cur.execute("""
            UPDATE items 
            SET nombre = %s, interes = %s, precio = %s, producto = %s, comentario = %s
            WHERE id = %s
        """, (nombre, interes, precio, producto, comentario, id))
        mysql.connection.commit()
        cur.close()
        flash('Ítem actualizado correctamente', 'success')
        return redirect(url_for('listar_items')) 

@app.route('/edit/<int:id>')
def get_item(id):
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM items WHERE id = %s', (id,))
    data = cur.fetchone() 
    cur.close()
    return render_template('edit.html', item=data)

@app.route('/delete/<string:id>')
def delete_item(id):
    cur = mysql.connection.cursor()
 
    cur.execute('DELETE FROM items WHERE id = %s', (id,))
    mysql.connection.commit()
    cur.close()
    flash('Ítem eliminado', 'success')
    return redirect(url_for('listar_items')) 



@app.errorhandler(404)
def page_not_found(e):
    """Manejador de error 404 (Página no encontrada)."""
    return render_template('404.html'), 404



if __name__ == '__main__': 

    app.run(debug=True)